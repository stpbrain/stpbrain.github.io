import React from 'react';
import {
  Bot,
  Cpu,
  Code2,
  BarChart3,
  Sparkles,
  Lightbulb,
  ArrowRight,
  CheckCircle2,
  MessageSquare,
  Mail,
} from 'lucide-react';

function App() {
  const services = [
    {
      icon: <Cpu className="w-12 h-12 text-blue-500" />,
      title: 'Automatización de procesos (RPA)',
      description: 'Optimiza tus operaciones y reduce costos con automatización inteligente',
    },
    {
      icon: <Code2 className="w-12 h-12 text-blue-500" />,
      title: 'Desarrollos low code',
      description: 'Soluciones rápidas y escalables sin código complejo',
    },
    {
      icon: <BarChart3 className="w-12 h-12 text-blue-500" />,
      title: 'Dashboards interactivos',
      description: 'Visualiza tus datos de forma clara y toma mejores decisiones',
    },
    {
      icon: <Sparkles className="w-12 h-12 text-blue-500" />,
      title: 'Integraciones con OpenAI',
      description: 'Potencia tu negocio con inteligencia artificial avanzada',
    },
  ];

  const steps = [
    {
      icon: <MessageSquare className="w-8 h-8 text-blue-500" />,
      title: 'Consulta inicial',
      description: 'Entendemos tus necesidades y objetivos específicos',
    },
    {
      icon: <Lightbulb className="w-8 h-8 text-blue-500" />,
      title: 'Propuesta personalizada',
      description: 'Diseñamos una solución adaptada a tu negocio',
    },
    {
      icon: <CheckCircle2 className="w-8 h-8 text-blue-500" />,
      title: 'Implementación',
      description: 'Ejecutamos la solución y te acompañamos en todo el proceso',
    },
  ];

  const testimonials = [
    {
      name: 'Carlos Rodríguez',
      role: 'Director de Operaciones',
      company: 'TechCorp',
      content: 'KobeAI transformó completamente nuestros procesos. La automatización nos permite ahorrar más de 30 horas semanales.',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80',
    },
    {
      name: 'Ana Martínez',
      role: 'CEO',
      company: 'Innovatech',
      content: 'La consultoría en IA nos ayudó a identificar oportunidades que no habíamos considerado. Excelente equipo profesional.',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <header className="relative overflow-hidden bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex items-center justify-center mb-8">
              <Bot className="w-12 h-12 text-blue-600" />
              <h1 className="text-4xl font-bold text-gray-900 ml-3">KobeAI</h1>
            </div>
            <h2 className="text-5xl font-extrabold text-gray-900 sm:text-6xl">
              Impulsa tu negocio con
              <span className="text-blue-600"> automatización inteligente</span>
            </h2>
            <p className="mt-6 text-xl text-gray-500 max-w-3xl mx-auto">
              Transformamos tu empresa con soluciones de automatización e inteligencia artificial personalizadas para maximizar tu eficiencia y productividad.
            </p>
            <div className="mt-10 flex justify-center gap-4">
              <a
                href="https://wa.me/1234567890"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
              >
                Contactar por WhatsApp
                <ArrowRight className="ml-2 w-5 h-5" />
              </a>
              <a
                href="mailto:contacto@kobeai.com"
                className="inline-flex items-center px-6 py-3 border border-gray-300 shadow-sm text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                <Mail className="mr-2 w-5 h-5" />
                contacto@kobeai.com
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Nuestros Servicios
            </h2>
            <p className="mt-4 text-lg text-gray-500">
              Soluciones integrales para la transformación digital de tu empresa
            </p>
          </div>
          <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((service, index) => (
              <div
                key={index}
                className="relative p-8 bg-white border border-gray-200 rounded-2xl shadow-sm flex flex-col hover:border-blue-500 transition-colors"
              >
                <div className="mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {service.title}
                </h3>
                <p className="text-gray-500">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Proceso Simple y Efectivo
            </h2>
            <p className="mt-4 text-lg text-gray-500">
              Te acompañamos en cada paso del camino
            </p>
          </div>
          <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-3">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">{step.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-gray-500">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Lo que dicen nuestros clientes
            </h2>
          </div>
          <div className="mt-16 grid grid-cols-1 gap-8 lg:grid-cols-2">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-2xl p-8 shadow-sm"
              >
                <div className="flex items-center mb-6">
                  <img
                    className="w-12 h-12 rounded-full"
                    src={testimonial.image}
                    alt={testimonial.name}
                  />
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold text-gray-900">
                      {testimonial.name}
                    </h4>
                    <p className="text-gray-500">
                      {testimonial.role} - {testimonial.company}
                    </p>
                  </div>
                </div>
                <p className="text-gray-600 italic">"{testimonial.content}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            ¿Listo para transformar tu negocio?
          </h2>
          <p className="mt-4 text-xl text-blue-100">
            Contáctanos ahora y descubre cómo podemos ayudarte
          </p>
          <div className="mt-8 flex justify-center gap-4">
            <a
              href="https://wa.me/1234567890"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover:bg-blue-50"
            >
              Contactar por WhatsApp
              <ArrowRight className="ml-2 w-5 h-5" />
            </a>
            <a
              href="mailto:contacto@kobeai.com"
              className="inline-flex items-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-blue-700"
            >
              <Mail className="mr-2 w-5 h-5" />
              contacto@kobeai.com
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;